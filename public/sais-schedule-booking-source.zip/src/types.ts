export type UserRole = 'admin' | 'inspector' | 'user' | 'viewer';
export type UserStatus = 'approved' | 'pending' | 'blocked';

export interface User {
  username: string;
  password?: string;
  full_name: string;
  department?: string;
  position?: string;
  phone?: string;
  email?: string;
  role: UserRole;
  status: UserStatus;
  inspector_mapped_name?: string;
  created_at?: string;
}

export interface Inspector {
  name: string;
  product_lines?: string;
}

export interface Booking {
  id: string;
  date: string; // YYYY-MM-DD
  inspector_name: string;
  site_name: string;
  equipment_no?: string;
  unit_no?: string;
  product_line?: string;
  job_type?: string;
  area?: string;
  tel?: string;
  map_link?: string;
  latitude?: number;
  longitude?: number;
  address_detail?: string;
  created_by?: string;
  status?: 'active' | 'cancelled';
  layout_doc?: 'true' | 'false' | 'pending';
  wiring_doc?: 'true' | 'false' | 'pending';
  precheck_doc?: 'true' | 'false' | 'pending';
  layout_img?: string;
  wiring_img?: string;
  precheck_img?: string;
  site_cond_1?: string;
  site_cond_2?: string;
  site_cond_3?: string;
  site_cond_4?: string;
  site_cond_5?: string;
  site_cond_6?: string;
  reason?: string;
}

export interface SystemNotification {
  id: string;
  title: string;
  message: string;
  target?: string;
  timestamp: string;
  isRead?: string;
}

export interface SystemLog {
  id?: string;
  action: string;
  details: string;
  user: string;
  timestamp: string;
}

export interface WebSettings {
  appName?: string;
  headerBg?: string;
  headerText?: string;
  appBg?: string;
  gridColWidth?: number | string;
  tableBorder?: string;
  tableHeaderBg?: string;
  tableHeaderText?: string;
  cardRadius?: number | string;
  cardPadding?: number | string;
  titleFontSize?: number | string;
  subFontSize?: number | string;
  normalBg?: string;
  normalText?: string;
  modBg?: string;
  modText?: string;
  upcBg?: string;
  upcText?: string;
  reinsBg?: string;
  reinsText?: string;
  holidayBg?: string;
  holidayText?: string;
  leaveBg?: string;
  leaveText?: string;
  eventBg?: string;
  eventText?: string;
}

export interface DayInfo {
  full: string;
  day: number;
  weekday: string;
  isSunday: boolean;
  isGlobalHoliday: boolean;
  globalHolidays: Booking[];
  isGlobalEvent: boolean;
  globalEvents: Booking[];
  isToday: boolean;
  isEmpty: boolean;
}
