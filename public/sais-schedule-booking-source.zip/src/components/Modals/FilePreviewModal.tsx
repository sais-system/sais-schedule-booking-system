import React from 'react';
import { Icons } from '../Icons';

interface FilePreviewModalProps {
  url: string;
  onClose: () => void;
}

export const FilePreviewModal: React.FC<FilePreviewModalProps> = ({ url, onClose }) => {
  const isPdf = url.endsWith('.pdf') || url.includes('application/pdf');

  return (
    <div className="backdrop z-[700] p-4 flex flex-col items-center justify-center">
      <div className="w-full max-w-4xl bg-white rounded-3xl overflow-hidden flex flex-col h-[85vh] shadow-2xl animate-pop relative">
        <div className="bg-slate-800 text-white p-3 flex justify-between items-center z-10 flex-shrink-0">
          <span className="font-bold text-sm flex items-center gap-2">
            <Icons.FileText /> ดูไฟล์แนบ / ภาพถ่าย
          </span>
          <div className="flex items-center gap-2">
            <a
              href={url}
              target="_blank"
              rel="noreferrer"
              className="bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1"
            >
              <Icons.Download /> เปิดแท็บใหม่
            </a>
            <button
              onClick={onClose}
              className="bg-white/20 hover:bg-white/30 p-1.5 rounded-full transition-colors"
            >
              <Icons.X />
            </button>
          </div>
        </div>

        <div className="flex-1 bg-slate-100 flex items-center justify-center p-2 overflow-hidden relative">
          {isPdf ? (
            <iframe src={url} className="w-full h-full border-0 rounded-2xl bg-white shadow-sm" title="PDF Preview" />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-black/5 rounded-2xl overflow-auto p-2">
              <img
                src={url}
                alt="Document Preview"
                className="max-w-full max-h-full object-contain rounded-xl shadow-sm"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
